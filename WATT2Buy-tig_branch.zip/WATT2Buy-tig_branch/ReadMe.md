This is the read me file

Changed by Hung
=======
Changed by Hung Bui
Changed by Kunal
Changed by Simon 
Reviewed by Vanessa
